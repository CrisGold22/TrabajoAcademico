package pe.edu.pucp.inf30.softprog.negocio;

/**
 * Hello world!
 */
public class App {
    public static void main(String[] args) {
        System.out.println("Hello World!");
    }
}
