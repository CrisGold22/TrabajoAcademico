/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.pucp.inf30.softprog.modelo.producto.utils;

/**
 *
 * @author Cristhian Horacio
 */
public enum TipoCategoria {
    ABARROTES, BEBIDAS, LIMPIEZA, CUIDADO_PERSONAL, ELECTRONICA, ROPA, HOGAR
}
